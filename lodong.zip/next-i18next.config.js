module.exports = {
  i18n: {
    locales: ["ko-KR"],
    defaultLocale: "ko-KR"
  }
};