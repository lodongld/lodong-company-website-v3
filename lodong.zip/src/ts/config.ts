export const animations = {

};